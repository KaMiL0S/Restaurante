<!DOCTYPE html>
<html lang="en">
<head>
<title>The Menu</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="<?php echo NAMEAPP; ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap-4.1.2/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link href="plugins/jquery-datepicker/jquery-ui.css" rel="stylesheet" type="text/css">
<link href="plugins/jquery-timepicker/jquery.timepicker.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/menu.css">
<link rel="stylesheet" type="text/css" href="styles/menu_responsive.css">
</head>
<body>

<div class="super_container">
	
	<!-- Header -->
	<?php include 'header.php' ?>
	
	<!-- hamburger -->
	<?php include 'hamburger.php.' ?>
	
	<!-- Home -->

	<div class="home">
		<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/menu.jpg" data-speed="0.8"></div>
		<div class="home_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_content text-center">
							<div class="home_subtitle page_subtitle"><?php echo NAMEAPP; ?></div>
							<div class="home_title"><h1>El Menú</h1></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- The Menu -->

	<div class="themenu">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<div class="section_subtitle page_subtitle">Algo nuevo</div>
						<div class="section_title"><h1>Descubre nuestro menú</h1></div>
					</div>
				</div>
			</div>
			<div class="row themenu_text_row">
				<div class="col-lg-6">
					<div class="themenu_text">
						<p>Están preparando en nuestra cocina este delicioso clásico de la cocina francesa " beef bourguignon".  <br>
						Reservas: ☎️ 347 79 39 
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="themenu_text">
						<p>Nuestra cava tiene la mejor selección de vinos para acompañar nuestros exquisitos platos.<br>
						"Un vino es ideal cuando uno lamenta haber acabado la botella" Roberto Verino

						Nuestra selección completa de vinos franceses, italianos y españoles todos con el 20% de descuento.
						</p>
					</div>
				</div>
			</div>
			<?php include'carta.php'; ?>
		</div>
	</div>

	<!-- Signature Dishes -->

	<div class="sig">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container">
						<div class="section_subtitle page_subtitle">Something new</div>
						<div class="section_title"><h1>Our Signature Dishes</h1></div>
					</div>
				</div>
			</div>
			<div class="row sig_row">
				<div class="col">
					
					<!-- Signature Dish -->
					<div class="sig_dish">
						<div class="row row-eq-height">
							<div class="col-lg-6 sig_col d-flex flex-column align-items-start justify-content-center">
								<div class="sig_content">
									<div class="rating_r sig_rating rating_r_5"><i></i><i></i><i></i><i></i><i></i></div>
									<div class="sig_name_container d-flex flex-row align-items-start justify-content-start">
										<div class="sig_name">Pork Tenderloin marinated in Green Pepper</div>
										<div class="sig_price ml-auto">$20</div>
									</div>
									<div class="sig_content_list">
										<ul class="d-flex flex-row align-items-center justify-content-start">
											<li>Pork</li>
											<li>Tenderloin</li>
											<li>Green Pepper</li>
											<li>Veggies</li>
										</ul>
									</div>
									<div class="button sig_button trans_200"><a href="#">Order Now</a></div>
								</div>
							</div>
							<div class="col-lg-6 sig_col">
								<div class="sig_image"><img src="images/sig_1.jpg" alt=""></div>
							</div>
						</div>
					</div>

					<!-- Signature Dish -->
					<div class="sig_dish">
						<div class="row row-eq-height">
							<div class="col-lg-6 sig_col d-flex flex-column align-items-start justify-content-center">
								<div class="sig_content">
									<div class="rating_r sig_rating rating_r_5"><i></i><i></i><i></i><i></i><i></i></div>
									<div class="sig_name_container d-flex flex-row align-items-start justify-content-start">
										<div class="sig_name">Beef Tartar with forest mushroms</div>
										<div class="sig_price ml-auto">$23</div>
									</div>
									<div class="sig_content_list">
										<ul class="d-flex flex-row align-items-center justify-content-start">
											<li>Pork</li>
											<li>Tenderloin</li>
											<li>Green Pepper</li>
											<li>Veggies</li>
										</ul>
									</div>
									<div class="button sig_button trans_200"><a href="#">Order Now</a></div>
								</div>
							</div>
							<div class="col-lg-6 sig_col">
								<div class="sig_image"><img src="images/sig_2.jpg" alt=""></div>
							</div>
						</div>
					</div>

					<!-- Signature Dish -->
					<div class="sig_dish">
						<div class="row row-eq-height">
							<div class="col-lg-6 sig_col d-flex flex-column align-items-start justify-content-center">
								<div class="sig_content">
									<div class="rating_r sig_rating rating_r_5"><i></i><i></i><i></i><i></i><i></i></div>
									<div class="sig_name_container d-flex flex-row align-items-start justify-content-start">
										<div class="sig_name">Beef Steak with sauted vegetables</div>
										<div class="sig_price ml-auto">$20</div>
									</div>
									<div class="sig_content_list">
										<ul class="d-flex flex-row align-items-center justify-content-start">
											<li>Pork</li>
											<li>Tenderloin</li>
											<li>Green Pepper</li>
											<li>Veggies</li>
										</ul>
									</div>
									<div class="button sig_button trans_200"><a href="#">Order Now</a></div>
								</div>
							</div>
							<div class="col-lg-6 sig_col">
								<div class="sig_image"><img src="images/sig_3.jpg" alt=""></div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- Reservations -->
	<?php include'reserva.php'; ?>

	<!-- Footer -->
	<?php include'footer.php'; ?>
	
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/jquery-datepicker/jquery-ui.js"></script>
<script src="plugins/jquery-timepicker/jquery.timepicker.js"></script>
<script src="js/menu.js"></script>
</body>
</html>