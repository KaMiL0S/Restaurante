<?php
$url= explode('/', $_SERVER['PHP_SELF']);
$url= array_pop($url);
?>
<div class="row themenu_row">
	
	<!-- Starters -->
	<div class="col-lg-4 themenu_column">
		<?php if($url=='menu.php'){ ?>
			<div class="themenu_image"><img src="images/starters.jpg" alt=""></div>
		<?php } ?>
		<div class="themenu_col trans_400">
			<div class="themenu_col_title">LES ENTRÉES - ENTRADAS</div>
			<div class="dish_list">

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Pleaurotes Gratinées</div>
						<div class="dish_price">$20</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Orellanas Gratinadas</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Champignons de Paris Gratinés</div>
						<div class="dish_price">$17</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Champiñones Gratinados</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Champignons de Paris à la Provençale</div>
						<div class="dish_price">$20</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Champiñones a la Provenzal, salsa de ajo y perejil</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Reins au Xérès</div>
						<div class="dish_price">$20</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Riñones al Jerez</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Soupe a l`Oignon Gratinée</div>
						<div class="dish_price">$17</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Sopa de Cebolla Gratinada</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Main -->
	<div class="col-lg-4 themenu_column">
		<?php if($url=='menu.php'){ ?>
			<div class="themenu_image"><img src="images/main.jpg" alt=""></div>
		<?php } ?>
		<div class="themenu_col trans_400">
			<div class="themenu_col_title">LES VIANDES - CARNES</div>
			<div class="dish_list">
				
				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Tournedos de Boeuf Grillé Sauce Béarnaise Henry IV</div>
						<div class="dish_price">$20</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Lomito de Res Asado Con Salsa Bearnesa</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Tournedos au Poivre Noir</div>
						<div class="dish_price">$20</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Lomito de Res a la Pimienta Negra</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Tournedos à la Moutarde de Dijon</div>
						<div class="dish_price">$17</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Lomito de Res a la Mostaza</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Tournedos au Poivre Vert</div>
						<div class="dish_price">$20</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Lomito de Res a la Pimienta Verde</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Medaillons de Bocuf aux Deux Poivres</div>
						<div class="dish_price">$20</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Medallones de Lomito de Res a las Dos Pimientas</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Filet Mignon</div>
						<div class="dish_price">$17</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Lomito de Res en salsa de Carne</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Deserts -->
	<div class="col-lg-4 themenu_column">
		<?php if($url=='menu.php'){ ?>
			<div class="themenu_image"><img src="images/deserts.jpg" alt=""></div>
		<?php } ?>
		<div class="themenu_col trans_400">
			<div class="themenu_col_title">DESSERTS - POSTRES</div>
			<div class="dish_list">

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Crepes Suzette</div>
						<div class="dish_price">$20</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Crepes S uzette</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Fraises Flambées au Cointreau</div>
						<div class="dish_price">$17</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Fresas Flambeadas al Cointreau</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Bananes Flambées au Cointreau</div>
						<div class="dish_price">$20</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Bananos Flambeados al Cointreau</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">Mousse au Chocolat Glace</div>
						<div class="dish_price">$17</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">Le Gateau Maison</div>
					</div>
				</div>

				<!-- Dish -->
				<div class="dish">
					<div class="dish_title_container d-flex flex-xl-row flex-column align-items-start justify-content-start">
						<div class="dish_title">El pastel de la Casa</div>
						<div class="dish_price">$17</div>
					</div>
					<div class="dish_contents">
						<div class="d-flex flex-row align-items-start justify-content-start flex-wrap">La Peach Melba de Michel</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>