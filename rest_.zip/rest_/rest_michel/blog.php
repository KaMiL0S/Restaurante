<!DOCTYPE html>
<html lang="en">
<head>
<title>Blog</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="The Venue template project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap-4.1.2/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link href="plugins/jquery-datepicker/jquery-ui.css" rel="stylesheet" type="text/css">
<link href="plugins/jquery-timepicker/jquery.timepicker.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/blog.css">
<link rel="stylesheet" type="text/css" href="styles/blog_responsive.css">
</head>
<body>

<div class="super_container">
	
	<!-- Header -->

	<header class="header">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="header_content d-flex flex-row align-items-center justify-content-start">
						<div class="logo">
							<a href="#">
								<div>The Venue</div>
								<div>restaurant</div>
							</a>
						</div>
						<nav class="main_nav">
							<ul class="d-flex flex-row align-items-center justify-content-start">
								<li><a href="index.html">home</a></li>
								<li><a href="about.html">about us</a></li>
								<li><a href="menu.html">menu</a></li>
								<li><a href="#">delivery</a></li>
								<li><a href="blog.html">blog</a></li>
								<li><a href="contact.html">contact</a></li>
							</ul>
						</nav>
						<div class="reservations_phone ml-auto">Reservations: +34 586 778 8892</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<!-- Hamburger -->
	
	<div class="hamburger_bar trans_400 d-flex flex-row align-items-center justify-content-start">
		<div class="hamburger">
			<div class="menu_toggle d-flex flex-row align-items-center justify-content-start">
				<span>menu</span>
				<div class="hamburger_container">
					<div class="menu_hamburger">
						<div class="line_1 hamburger_lines" style="transform: matrix(1, 0, 0, 1, 0, 0);"></div>
						<div class="line_2 hamburger_lines" style="visibility: inherit; opacity: 1;"></div>
						<div class="line_3 hamburger_lines" style="transform: matrix(1, 0, 0, 1, 0, 0);"></div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Menu -->

	<div class="menu trans_800">
		<div class="menu_content d-flex flex-column align-items-center justify-content-center text-center">
			<ul>
				<li><a href="index.html">home</a></li>
				<li><a href="about.html">about us</a></li>
				<li><a href="menu.html">menu</a></li>
				<li><a href="#">delivery</a></li>
				<li><a href="blog.html">blog</a></li>
				<li><a href="contact.html">contact</a></li>
			</ul>
		</div>
		<div class="menu_reservations_phone ml-auto">Reservations: +34 586 778 8892</div>
	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/blog.jpg" data-speed="0.8"></div>
		<div class="home_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_content text-center">
							<div class="home_subtitle page_subtitle">The Venue</div>
							<div class="home_title"><h1>Our Blog</h1></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Blog -->

	<div class="blog">
		<div class="container">
			<div class="row">

				<!-- Blog Post -->
				<div class="col-lg-6 blog_col">
					<div class="blog_post">
						<div class="blog_post_image_container">
							<div class="blog_post_image"><img src="images/blog_1.jpg" alt="https://unsplash.com/@patrick_schneider"></div>
							<div class="blog_post_date"><a href="#">June 18, 2018</a></div>
						</div>
						<div class="blog_post_content">
							<div class="blog_post_title"><a href="#">Our Nomenee at the Restaurants Awards</a></div>
							<div class="blog_post_info">
								<ul class="d-flex flex-row align-items-center justify-content-start">
									<li>by <a href="#">George Smith</a></li>
									<li>in <a href="#">Lifestyle</a></li>
									<li><a href="#">2 Comments</a></li>
								</ul>
							</div>
							<div class="blog_post_text">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Ut non justo eleifend, facilisis nibh ut, interdum odio. Suspendisse potenti.</p>
							</div>
						</div>
					</div>
				</div>

				<!-- Blog Post -->
				<div class="col-lg-6 blog_col">
					<div class="blog_post">
						<div class="blog_post_image_container">
							<div class="blog_post_image"><img src="images/blog_2.jpg" alt="https://unsplash.com/@tashytown"></div>
							<div class="blog_post_date"><a href="#">June 18, 2018</a></div>
						</div>
						<div class="blog_post_content">
							<div class="blog_post_title"><a href="#">Recipe of the week</a></div>
							<div class="blog_post_info">
								<ul class="d-flex flex-row align-items-center justify-content-start">
									<li>by <a href="#">George Smith</a></li>
									<li>in <a href="#">Lifestyle</a></li>
									<li><a href="#">2 Comments</a></li>
								</ul>
							</div>
							<div class="blog_post_text">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Ut non justo eleifend, facilisis nibh ut, interdum odio. Suspendisse potenti.</p>
							</div>
						</div>
					</div>
				</div>

				<!-- Blog Post -->
				<div class="col-lg-6 blog_col">
					<div class="blog_post">
						<div class="blog_post_image_container">
							<div class="blog_post_image"><img src="images/blog_3.jpg" alt="https://unsplash.com/@stefanjonhson"></div>
							<div class="blog_post_date"><a href="#">June 18, 2018</a></div>
						</div>
						<div class="blog_post_content">
							<div class="blog_post_title"><a href="#">Our Nomenee at the Restaurants Awards</a></div>
							<div class="blog_post_info">
								<ul class="d-flex flex-row align-items-center justify-content-start">
									<li>by <a href="#">George Smith</a></li>
									<li>in <a href="#">Lifestyle</a></li>
									<li><a href="#">2 Comments</a></li>
								</ul>
							</div>
							<div class="blog_post_text">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Ut non justo eleifend, facilisis nibh ut, interdum odio. Suspendisse potenti.</p>
							</div>
						</div>
					</div>
				</div>

				<!-- Blog Post -->
				<div class="col-lg-6 blog_col">
					<div class="blog_post">
						<div class="blog_post_image_container">
							<div class="blog_post_image"><img src="images/blog_4.jpg" alt="Jackelin Slack"></div>
							<div class="blog_post_date"><a href="#">June 18, 2018</a></div>
						</div>
						<div class="blog_post_content">
							<div class="blog_post_title"><a href="#">Our Nomenee at the Restaurants Awards</a></div>
							<div class="blog_post_info">
								<ul class="d-flex flex-row align-items-center justify-content-start">
									<li>by <a href="#">George Smith</a></li>
									<li>in <a href="#">Lifestyle</a></li>
									<li><a href="#">2 Comments</a></li>
								</ul>
							</div>
							<div class="blog_post_text">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Ut non justo eleifend, facilisis nibh ut, interdum odio. Suspendisse potenti.</p>
							</div>
						</div>
					</div>
				</div>

				<!-- Blog Post -->
				<div class="col-lg-6 blog_col">
					<div class="blog_post">
						<div class="blog_post_image_container">
							<div class="blog_post_image"><img src="images/blog_5.jpg" alt="https://unsplash.com/@mantra_media_ltd"></div>
							<div class="blog_post_date"><a href="#">June 18, 2018</a></div>
						</div>
						<div class="blog_post_content">
							<div class="blog_post_title"><a href="#">Our Nomenee at the Restaurants Awards</a></div>
							<div class="blog_post_info">
								<ul class="d-flex flex-row align-items-center justify-content-start">
									<li>by <a href="#">George Smith</a></li>
									<li>in <a href="#">Lifestyle</a></li>
									<li><a href="#">2 Comments</a></li>
								</ul>
							</div>
							<div class="blog_post_text">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Ut non justo eleifend, facilisis nibh ut, interdum odio. Suspendisse potenti.</p>
							</div>
						</div>
					</div>
				</div>

				<!-- Blog Post -->
				<div class="col-lg-6 blog_col">
					<div class="blog_post">
						<div class="blog_post_image_container">
							<div class="blog_post_image"><img src="images/blog_6.jpg" alt="https://unsplash.com/@brookelark"></div>
							<div class="blog_post_date"><a href="#">June 18, 2018</a></div>
						</div>
						<div class="blog_post_content">
							<div class="blog_post_title"><a href="#">Our Nomenee at the Restaurants Awards</a></div>
							<div class="blog_post_info">
								<ul class="d-flex flex-row align-items-center justify-content-start">
									<li>by <a href="#">George Smith</a></li>
									<li>in <a href="#">Lifestyle</a></li>
									<li><a href="#">2 Comments</a></li>
								</ul>
							</div>
							<div class="blog_post_text">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Ut non justo eleifend, facilisis nibh ut, interdum odio. Suspendisse potenti.</p>
							</div>
						</div>
					</div>
				</div>

			</div>
			<div class="row load_more_row">
				<div class="col">
					<div class="button load_more_button ml-auto mr-auto trans_200"><a href="#">Load More</a></div>
				</div>
			</div>
		</div>
	</div>

	<!-- Reservations -->

	<div class="reservations text-center">
		<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/reservations.jpg" data-speed="0.8"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="reservations_content d-flex flex-column align-items-center justify-content-center">
						<div class="res_stars page_subtitle">5 Stars</div>
						<div class="res_title">Make a Reservation</div>
						<div class="res_form_container">
							<form action="#" id="res_form" class="res_form">
								<div class="d-flex flex-sm-row flex-column align-items-center justify-content-start">
									<input type="text" id="datepicker" class="res_input" required="required">
									<input type="text" class="res_input timepicker" required="required">
									<select class="res_select">
										<option disabled="" selected="">2 person</option>
										<option>3 person</option>
										<option>4 person</option>
										<option>5 person</option>
										<option>6 person</option>
									</select>
								</div>
								<button class="res_button">Make a Reservation</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>		
	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">

				<!-- Footer Logo -->
				<div class="col-lg-3 footer_col">
					<div class="footer_logo">
						<div class="footer_logo_title">The Venue</div>
						<div class="footer_logo_subtitle">restaurant</div>
					</div>
					<div class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
<p style="line-height: 1.2;">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
				</div>

				<!-- Footer About -->
				<div class="col-lg-6 footer_col">
					<div class="footer_about">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Ut non justo eleifend, facilisis nibh ut, interdum odio.</p>
					</div>
				</div>

				<!-- Footer Contact -->
				<div class="col-lg-3 footer_col">
					<div class="footer_contact">
						<ul>
							<li class="d-flex flex-row align-items-start justify-content-start">
								<div><div class="footer_contact_title">Address:</div></div>
								<div class="footer_contact_text">481 Creekside Lane Avila CA 93424</div>
							</li>
							<li class="d-flex flex-row align-items-start justify-content-start">
								<div><div class="footer_contact_title">Address:</div></div>
								<div class="footer_contact_text">+53 345 7953 32453</div>
							</li>
							<li class="d-flex flex-row align-items-start justify-content-start">
								<div><div class="footer_contact_title">Address:</div></div>
								<div class="footer_contact_text">yourmail@gmail</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/jquery-datepicker/jquery-ui.js"></script>
<script src="plugins/jquery-timepicker/jquery.timepicker.js"></script>
<script src="js/blog.js"></script>
</body>
</html>