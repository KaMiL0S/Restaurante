<?php require_once 'config/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo NAMEAPP; ?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="<?php echo NAMEAPP; ?>">
<link rel="shortcut icon" href="imges/favicon.ico" type="image/x-icon">
<link rel="icon" href="imges/favicon.ico" type="image/x-icon">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap-4.1.2/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link href="plugins/jquery-datepicker/jquery-ui.css" rel="stylesheet" type="text/css">
<link href="plugins/jquery-timepicker/jquery.timepicker.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/responsive.css">
</head>
<body>

<div class="super_container">
	
	<!-- Header -->
	<?php include 'header.php' ?>

	<!-- hamburger -->
	<?php include 'hamburger.php' ?>


	<!-- Home -->
	<div class="home">
		<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/home.jpg" data-speed="0.8"></div>
		<div class="home_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_content text-center">
							<div class="home_subtitle page_subtitle"><?php echo NAMEAPP; ?></div>
							<div class="home_title"><h1>Una experiencia extraordinaria</h1></div>
							<div class="home_text ml-auto mr-auto">
								<p id="descripc">Disfruta de la gastronomía Mediterranea a través de nuestros sabores  26 años deleitando paladares</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="scroll_icon"></div>
	</div>

	<!-- Intro -->

	<div class="intro">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="intro_content">
						<div class="intro_subtitle page_subtitle">Desde 1991</div>
						<div class="intro_title"><h2>Cocina Mediterranea</h2></div>
						<div class="intro_text">
							<p>
								* Catering<br>
								* Ideal para grupos<br>
								* Acepta reservas<br>
								* Para llevar<br>
								* No requiere reservas<br>
							</p>
						</div>
					</div>
					<div class="row">
						<div class="col-xl-4 col-md-6 intro_col">
							<div class="intro_image"><img src="images/intro_1.jpg" alt="https://unsplash.com/@quanle2819"></div>
						</div>
						<div class="col-xl-4 col-md-6 intro_col">
							<div class="intro_image"><img src="images/intro_2.jpg" alt="https://unsplash.com/@fabmag"></div>
						</div>
					</div>
				</div>	
			</div>
		</div>
	</div>

	<!-- Video -->

	<div class="video_section">
		<div class="background_image" style="background-image:url(images/video.jpg)"></div>
		<div class="video_section_content d-flex flex-column align-items-center justify-content-center text-center">
			<div class="video_section_title">Desde 1991 </div>
			<div class="video_section_icon"><a class="vimeo video_button" 
				href="video/video_michel.mp4?autoplay=1&loop=1&title=0&autopause=0"><i class="fa fa-play" aria-hidden="true"></i></a></div>
		</div>
	</div>

	<!-- Signature Dish -->

	<div class="sig">

	</div>

	<!-- The Menu -->

		<div class="themenu">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="themenu_title_bar_container">
							<div class="themenu_stars text-center page_subtitle"><?php echo NAMEAPP; ?></div>
							<div class="themenu_rating text-center">
								<div class="rating_r rating_r_5"><i></i><i></i><i></i><i></i><i></i></div>
							</div>
							<div class="themenu_title_bar d-flex flex-column align-items-center justify-content-center">
								<div class="themenu_title">The Menu</div>
							</div>
						</div>
					</div>
				</div>
				<?php include'carta.php'; ?>
			</div>		
		</div>

	<!-- Reservations -->
	<?php include'reserva.php'; ?>

	<!-- Footer -->
	<?php include'footer.php'; ?>

</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="plugins/jquery-datepicker/jquery-ui.js"></script>
<script src="plugins/jquery-timepicker/jquery.timepicker.js"></script>
<script src="js/custom.js"></script>
</body>
</html>