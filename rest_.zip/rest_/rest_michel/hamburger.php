<!-- Hamburger -->

<div class="hamburger_bar trans_400 d-flex flex-row align-items-center justify-content-start">
	<div class="hamburger">
		<div class="menu_toggle d-flex flex-row align-items-center justify-content-start">
			<span>menu</span>
			<div class="hamburger_container">
				<div class="menu_hamburger">
					<div class="line_1 hamburger_lines" style="transform: matrix(1, 0, 0, 1, 0, 0);"></div>
					<div class="line_2 hamburger_lines" style="visibility: inherit; opacity: 1;"></div>
					<div class="line_3 hamburger_lines" style="transform: matrix(1, 0, 0, 1, 0, 0);"></div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Menu -->

<div class="menu trans_800">
	<div class="menu_content d-flex flex-column align-items-center justify-content-center text-center">
		<ul>
			<li><a href="index.php">Inicio</a></li>
			<!-- <li><a href="about.php">Nosotros</a></li>
			<li><a href="menu.php">Menu</a></li>
			<li><a href="contact.php">Contacto</a></li> -->
			<li><a href="#reserva" onclick="$('.line_3').trigger('click'); ">Reserva</a></li>
		</ul>
	</div>
	<div class="reservations_phone ml-auto">Reserva: 
		<a href="tel:XXXXXXX" style="color: #ffffff"> XXX XX XX
	</div>
</div>