<footer class="footer">
	<div class="container">
		<div class="row">

			<!-- Footer Logo -->
			<div class="col-lg-3 footer_col">
				<div class="footer_logo">
					<div class="footer_logo_title"><?php echo NAMEAPP; ?></div>
					<div class="footer_logo_subtitle">restaurant</div>
				</div>
				<div class="copyright">
					<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
					<p style="line-height: 1.2;">Copyright &copy;
						<script>
							document.write(new Date().getFullYear());
						</script> Todos los derechos reservados
					</p>
					<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
				</div>
			</div>

			<!-- Footer About -->
			<div class="col-lg-6 footer_col">
				<div class="footer_about">
					<p>Disfruta de la gastronomía francesa a través de nuestros sabores 26 años deleitando paladares</p>
				</div>
			</div>

			<!-- Footer Contact -->
			<div class="col-lg-3 footer_col">
				<div class="footer_contact">
					<ul>
						<li class="d-flex flex-row align-items-start justify-content-start">
							<div><div class="footer_contact_title">Dirección:</div></div>
							<div class="footer_contact_text"><?php echo ADDRESS ?></div>
						</li>
						<li class="d-flex flex-row align-items-start justify-content-start">
							<div><div class="footer_contact_title">Telefono:</div></div>
							<div class="footer_contact_text"><?php echo PHONE ?></div>
						</li>
						<li class="d-flex flex-row align-items-start justify-content-start">
							<div><div class="footer_contact_title">Correo:</div></div>
							<div class="footer_contact_text"><?php echo EMAIL ?></div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</footer>