<style type="text/css">
	#btnWhatsApp {
bottom: 2%;
    left: 10px;
    z-index: 10000;
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 150px;
    background-color: #189D0E;
    color: white !important;
    margin: 0% 2% 0% 2%;
	}

#btnWhatsApp .fa-whatsapp {
    font-size: 40px;
    margin-left: -3%;
}	
</style>

<?php require_once 'config/config.php'; ?>
<header class="header">
	<div class="container">
		<div class="row">
			<div class="col">
				<div class="header_content d-flex flex-row align-items-center justify-content-start">
					<div class="logo">
						<a href="index.php">
							<div><?php echo NAMEAPP; ?></div>
							<div>restaurant</div>
						</a>
					</div>
					<nav class="main_nav">
						<ul class="d-flex flex-row align-items-center justify-content-start">
							<li><a href="index.php">Inicio</a></li>
							<!-- <li><a href="about.php">Nosotros</a></li>
							<li><a href="menu.php">Menu</a></li>
							<li><a href="contact.php">Contacto</a></li> -->
							<li><a href="#reserva">Reserva</a></li>
						</ul>
					</nav>
					<div class="reservations_phone ml-auto">Reserva: 
						<a href="tel:0313477939" style="color: #ffffff"> XXX XX XX
					</div>

					<div id="btnWhatsApp">
					  <a style="color: #ffffff" target="_blanck" 
					  	 href="https://api.whatsapp.com/send?phone=XXXXXXXXXXX&amp;text=Hola,%20quiero%20reservar%20por%20favor">
					    <i class="fa fa-whatsapp" aria-hidden="true"></i>
					  </a>
					</div>

				</div>
			</div>
		</div>
	</div>
</header>