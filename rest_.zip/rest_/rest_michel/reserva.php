<div id="reserva" class="reservations text-center">
	<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/reservations.jpg" data-speed="0.8"></div>
	<div class="container">
		<div class="row">
			<div class="col">
				<div class="reservations_content d-flex flex-column align-items-center justify-content-center">
					<div class="res_stars page_subtitle"><!--5 Stars--></div>
					<div class="res_title">Hacer una reserva</div>
					<div class="res_form_container">
						<form action="#" id="res_form" class="res_form">
							<div class="d-flex flex-sm-row flex-column align-items-center justify-content-start">
								<input type="text" id="datepicker" class="res_input" required="required">
								<input type="text" class="res_input timepicker" required="required">
								<select class="res_select">
									<option disabled="" selected="">1-2 personas</option>
									<option>3 personas</option>
									<option>4 personas</option>
									<option>5 personas</option>
									<option>6 personas</option>
									<option>6 o más personas</option>
								</select>
							</div>
							<button class="res_button">Reservar</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>		
</div>