<?php
include '../config/config.php';

// Create connection
$conn = mysqli_connect(LOCALHOST, USUARIO, PASSWORD, BASEDATOS);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

?>