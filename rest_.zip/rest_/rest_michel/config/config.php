<?php
//Nombre del aplicativo
define('NAMEAPP','Mediterranean Food');
//Motor de la base de datos
define('LOCALHOST','127.0.0.1');
//Usuario de la base de datos
define('USUARIO','root');
//Contraseña de base de datos
define('PASSWORD','');
//Nombre de la base de datos
define('BASEDATOS','');

//Direccion Fisica
define('ADDRESS','CALLE XX A # X-XX');

//Telefono
define('PHONE','XXX XX XX');

//Email
define('EMAIL','MediterraneanFood@MediterraneanFood.com.co');

//Pagina Facebook
define('FACEBOOK','https://www.facebook.com/MediterraneanFood');


?>